window.onload = function() {
    fetch('lat_lon_time_ISS.txt')
        .then(response => response.text())
        .then(data => {
            const coordinates = parseData(data);
            console.log('Parsed cordinates:', coordinates);

            document.getElementById('filter-button').addEventListener('click', () => {
                const startTime = new Date(document.getElementById('start-time').value);
                const endTime = new Date(document.getElementById('end-time').value);
                const filteredCoordinates = filterCoordinatesByTime(coordinates, startTime, endTime);
                console.log('Filtered coordinates:', filteredCoordinates);
                initMap(filteredCoordinates);
            });

            initMap(coordinates);  
        })
        .catch(error => {
            console.error('Error:', error);
        });
};

function parseData(data) {
    const lines = data.trim().split('\n');
    return lines.map(line => {
        const [lat, lon, timestamp] = line.split(',');
        const date = new Date(timestamp * 1000);
        return {
            lat: parseFloat(lat),
            lon: parseFloat(lon),
            date: date,
            timestamp: parseInt(timestamp)
        };
    });
}

function filterCoordinatesByTime(coordinates, startTime, endTime) {
    return coordinates.filter(coord => coord.date >= startTime && coord.date <= endTime);
}

function initMap(coordinates) {
    const map = new Microsoft.Maps.Map('#map', {
        center: new Microsoft.Maps.Location(0, 0),
        zoom: 3
    });

    const locations = coordinates.map(coord => new Microsoft.Maps.Location(coord.lat, coord.lon));
    console.log('Lokacije:', locations);

    const polyline = new Microsoft.Maps.Polyline(locations, {
        strokeColor: 'red',
        strokeThickness: 2
    });

    map.entities.clear();  
    map.entities.push(polyline);
    map.setView({ bounds: Microsoft.Maps.LocationRect.fromLocations(locations) });
}


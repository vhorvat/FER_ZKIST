import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SimpleHttpServer {

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/", new MyHandler());
        server.setExecutor(null); 
        server.start();
        System.out.println("Server started");
    }

    static class MyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            String path = t.getRequestURI().getPath();
            System.out.println("Request za: " + path);

            if (path.equals("/")) {
                path = "/index.html";
            }

            byte[] response;
            try {
                response = Files.readAllBytes(Paths.get("web" + path));
                t.getResponseHeaders().add("Content-Type", getMimeType(path));
                t.sendResponseHeaders(200, response.length);
            } catch (IOException e) {
                String errorMessage = "404\n";
                response = errorMessage.getBytes();
                t.sendResponseHeaders(404, response.length);
                System.out.println("File not found: " + path);
            }

            OutputStream os = t.getResponseBody();
            os.write(response);
            os.close();
        }

        private String getMimeType(String path) {
            if (path.endsWith(".html")) return "text/html";
            if (path.endsWith(".css")) return "text/css";
            if (path.endsWith(".js")) return "application/javascript";
            return "application/octet-stream";
        }
    }
}
